plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.sada.walkie"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.sada.walkie"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "2.2"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // ماسح QR جاهز من خدمات Google (يعمل من داخل التطبيق بدون إذن كاميرا مستقل)
    implementation("com.google.android.gms:play-services-code-scanner:16.1.0")
    // توليد رمز QR
    implementation("com.google.zxing:core:3.5.3")
}
