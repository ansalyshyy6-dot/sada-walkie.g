package com.sada.walkie

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.google.android.gms.code_scanner.GmsBarcodeScannerOptions
import com.google.android.gms.code_scanner.GmsBarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import org.json.JSONArray
import org.json.JSONObject

private const val RC_MIC = 1
private const val RC_NET = 2

// كل مضيف ينشئ شبكة اسمها PREFIX + اسم هاتفه، وكلمة سرها ثابتة معروفة للتطبيق.
// (يجب أن يبدأ الاسم بـ DIRECT-xy- ليقبله Wi-Fi Direct)
private const val PREFIX = "DIRECT-sa-SADA-"
private const val FIX_PASS = "88888888"   // الرمز الافتراضي (يمكن تغييره من التطبيق)

class MainActivity : Activity() {
    private lateinit var radio: Radio
    private lateinit var wv: WebView
    private var hs: WifiManager.LocalOnlyHotspotReservation? = null
    private var p2p: WifiP2pManager? = null
    private var p2pCh: WifiP2pManager.Channel? = null
    @Volatile private var hsInfo = ""
    @Volatile private var mySsid = PREFIX + "PHONE"
    @Volatile private var myPass = FIX_PASS
    @Volatile private var joinState = ""
    private var joinCb: ConnectivityManager.NetworkCallback? = null

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun hasMic() = granted(Manifest.permission.RECORD_AUDIO)
    private fun netPerm() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.NEARBY_WIFI_DEVICES
    else Manifest.permission.ACCESS_FINE_LOCATION

    private fun svc() = Intent(this, WalkieService::class.java)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.parseColor("#F93A3A")
        window.navigationBarColor = Color.parseColor("#B3000D")
        volumeControlStream = AudioManager.STREAM_MUSIC   // أزرار الصوت تتحكم بقوة اللاسلكي
        radio = Radio.get(this)

        wv = WebView(this)
        wv.setBackgroundColor(Color.parseColor("#D4121B"))
        wv.overScrollMode = View.OVER_SCROLL_NEVER
        wv.isVerticalScrollBarEnabled = false
        wv.setOnLongClickListener { true }
        setContentView(wv)
        with(wv.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowContentAccess = false
            setSupportZoom(false)
            textZoom = 100
        }
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.loadUrl("file:///android_asset/index.html")
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(rc, perms, res)
        val ok = when (rc) {
            RC_MIC -> hasMic()
            RC_NET -> granted(netPerm())
            else -> return
        }
        wv.evaluateJavascript("window.onPerm&&window.onPerm($rc,$ok)", null)
    }

    // زر الرجوع: يغلق النافذة المفتوحة، وإلا يُبقي التطبيق يعمل بالخلفية
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        wv.evaluateJavascript(
            "(function(){var s=document.getElementById('sheet');if(s&&!s.hidden){s.hidden=true;return 1}return 0})()"
        ) { r -> if (r != "1") moveTaskToBack(true) }
    }

    override fun onDestroy() {
        if (isFinishing) {
            radio.stop()
            stopService(svc())
            stopHost()
            leaveNetwork()
        }
        super.onDestroy()
    }

    private fun leaveNetwork() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        try { cm.bindProcessToNetwork(null) } catch (_: Exception) {}
        joinCb?.let { try { cm.unregisterNetworkCallback(it) } catch (_: Exception) {} }
        joinCb = null
        joinState = ""
    }

    // ---------- المضيف: شبكة ثابتة (Wi-Fi Direct) مع بديل هوتسبوت عشوائي ----------

    private fun info(ssid: String?, pass: String?, fixed: Boolean) {
        hsInfo = JSONObject().put("ssid", ssid ?: "").put("pass", pass ?: "").put("fixed", fixed).toString()
    }

    private fun stopHost() {
        try { hs?.close() } catch (_: Exception) {}
        hs = null
        try { p2p?.removeGroup(p2pCh, null) } catch (_: Exception) {}
        hsInfo = ""
    }

    @SuppressLint("MissingPermission")
    private fun startDirect(retry: Boolean = true): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        return try {
            val m = p2p ?: (getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager) ?: return false
            val ch = p2pCh ?: m.initialize(this, Looper.getMainLooper(), null) ?: return false
            p2p = m; p2pCh = ch
            val cfg = WifiP2pConfig.Builder()
                .setNetworkName(mySsid)
                .setPassphrase(myPass)
                .enablePersistentMode(false)
                .build()
            m.createGroup(ch, cfg, object : WifiP2pManager.ActionListener {
                override fun onSuccess() { info(mySsid, myPass, true) }
                override fun onFailure(reason: Int) {
                    if (reason == WifiP2pManager.BUSY && retry) {
                        // توجد مجموعة قديمة: أزلها ثم أعد المحاولة مرة واحدة
                        m.removeGroup(ch, object : WifiP2pManager.ActionListener {
                            override fun onSuccess() { if (!startDirect(false)) startLocalOnly() }
                            override fun onFailure(r: Int) { startLocalOnly() }
                        })
                    } else startLocalOnly()
                }
            })
            true
        } catch (_: Exception) { false }
    }

    @SuppressLint("MissingPermission")
    private fun startLocalOnly() {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(r: WifiManager.LocalOnlyHotspotReservation) {
                    hs = r
                    if (Build.VERSION.SDK_INT >= 30) {
                        val c = r.softApConfiguration; info(c.ssid, c.passphrase, false)
                    } else {
                        @Suppress("DEPRECATION")
                        val c = r.wifiConfiguration; info(c?.SSID, c?.preSharedKey, false)
                    }
                }
                override fun onFailed(reason: Int) { hsInfo = "ERR:$reason" }
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) { hsInfo = "ERR:" + e.message }
    }

    // ---------- الانضمام لشبكة (من داخل التطبيق) ----------

    private fun doJoin(ssid: String, pass: String, timeoutMs: Int): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        if (!granted(netPerm())) {
            runOnUiThread { requestPermissions(arrayOf(netPerm()), RC_NET) }
            return false
        }
        val spec = WifiNetworkSpecifier.Builder().setSsid(ssid).setWpa2Passphrase(pass).build()
        val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).setNetworkSpecifier(spec).build()
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        try { cm.bindProcessToNetwork(null) } catch (_: Exception) {}
        joinCb?.let { try { cm.unregisterNetworkCallback(it) } catch (_: Exception) {} }
        joinState = "WAIT"
        val cb = object : ConnectivityManager.NetworkCallback() {
            // تُستدعى أيضاً عند عودة الشبكة بعد انقطاعها: إعادة اتصال تلقائية
            override fun onAvailable(n: Network) {
                if (cm.bindProcessToNetwork(n)) {
                    joinState = "OK"
                    if (radio.running) radio.restart()      // إعادة ربط المقبس بالشبكة الجديدة
                } else joinState = "ERR"
            }
            override fun onUnavailable() { try { cm.bindProcessToNetwork(null) } catch (_: Exception) {}; joinState = "ERR" }
            override fun onLost(n: Network) {
                try { cm.bindProcessToNetwork(null) } catch (_: Exception) {}
                joinState = "LOST"
                if (radio.running) radio.restart()
            }
        }
        joinCb = cb
        return try { cm.requestNetwork(req, cb, timeoutMs); true } catch (_: Exception) { joinState = "ERR"; false }
    }

    inner class Bridge {
        // ---------- التشغيل ----------
        @JavascriptInterface fun hasMic(): Boolean = this@MainActivity.hasMic()
        @JavascriptInterface fun hasNetPerm(): Boolean = granted(netPerm())
        @JavascriptInterface fun reqNetPerm() { runOnUiThread { requestPermissions(arrayOf(netPerm()), RC_NET) } }

        @JavascriptInterface fun start(): Boolean {
            if (!this@MainActivity.hasMic()) {
                val list = mutableListOf(Manifest.permission.RECORD_AUDIO)
                if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS))
                    list.add(Manifest.permission.POST_NOTIFICATIONS)
                runOnUiThread { requestPermissions(list.toTypedArray(), RC_MIC) }
                return false
            }
            val ok = radio.start()
            if (ok) runOnUiThread { try { startForegroundService(svc()) } catch (_: Exception) {} }
            return ok
        }

        @JavascriptInterface fun stop() {
            radio.stop()
            runOnUiThread { stopService(svc()) }
        }

        @JavascriptInterface fun running(): Boolean = radio.running
        @JavascriptInterface fun talk(on: Boolean) = radio.talk(on)
        @JavascriptInterface fun peers(): Int = radio.peers()
        @JavascriptInterface fun receiving(): Boolean = System.currentTimeMillis() - radio.lastRx < 500
        @JavascriptInterface fun setChannel(c: Int) { radio.channel = c.coerceIn(1, 8) }
        @JavascriptInterface fun setListen(l: Boolean) { radio.listen = l }

        // ---------- الصوت والشاشة ----------
        @JavascriptInterface fun setBoost(l: Int) { radio.boost = l.coerceIn(0, 3); radio.applyVolume() }
        @JavascriptInterface fun setPhoneAudio(on: Boolean) { radio.phoneAudio = on; radio.applyVolume() }
        @JavascriptInterface fun keepScreen(on: Boolean) = runOnUiThread {
            if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        @JavascriptInterface fun haptic() = runOnUiThread {
            wv.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }

        // ---------- إنشاء الشبكة (مضيف) ----------
        // النتيجة JSON: {"ssid":..,"pass":..,"fixed":true|false} أو نص يبدأ بـ ERR
        @JavascriptInterface fun hotspotStart(code: String): Boolean {
            if (!granted(netPerm())) {
                runOnUiThread { requestPermissions(arrayOf(netPerm()), RC_NET) }
                return false
            }
            myPass = if (code.length in 8..63) code else FIX_PASS
            val model = Build.MODEL.filter { it.isLetterOrDigit() }.take(10).ifEmpty { "PHONE" }
            mySsid = PREFIX + model + (10..99).random()
            runOnUiThread {
                stopHost()
                if (!startDirect()) startLocalOnly()
            }
            return true
        }
        @JavascriptInterface fun hotspotInfo(): String = hsInfo
        @JavascriptInterface fun hotspotStop() { runOnUiThread { stopHost() } }

        // ---------- الانضمام ----------
        @JavascriptInterface fun fixedPass(): String = FIX_PASS

        /** البحث عن شبكات الفريق القريبة: JSON [{"ssid":..,"level":..}] */
        @SuppressLint("MissingPermission")
        @JavascriptInterface fun scanNetworks(): String {
            if (!granted(netPerm())) return "[]"
            val arr = JSONArray()
            try {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                try { wm.startScan() } catch (_: Exception) {}
                val seen = HashSet<String>()
                @Suppress("DEPRECATION")
                for (r in wm.scanResults) {
                    val n = r.SSID ?: continue
                    if (n.startsWith(PREFIX) && seen.add(n))
                        arr.put(JSONObject().put("ssid", n).put("level", WifiManager.calculateSignalLevel(r.level, 4)))
                }
            } catch (_: Exception) {}
            return arr.toString()
        }

        /** رسم رمز QR: أسطر من 0/1 مفصولة بسطر جديد. */
        @JavascriptInterface fun qrMatrix(text: String): String = try {
            val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 1, 1)
            val sb = StringBuilder()
            for (y in 0 until m.height) {
                for (x in 0 until m.width) sb.append(if (m.get(x, y)) '1' else '0')
                sb.append('\n')
            }
            sb.toString()
        } catch (_: Exception) { "" }

        /** مسح رمز QR بالكاميرا؛ النتيجة تصل عبر window.onQr(text|null). */
        @JavascriptInterface fun scanQr() {
            runOnUiThread {
                val send = { v: String? ->
                    wv.evaluateJavascript("window.onQr&&window.onQr(" + (if (v == null) "null" else JSONObject.quote(v)) + ")", null)
                }
                try {
                    val opt = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
                    GmsBarcodeScanning.getClient(this@MainActivity, opt).startScan()
                        .addOnSuccessListener { b -> send(b.rawValue) }
                        .addOnFailureListener { send(null) }
                        .addOnCanceledListener { send(null) }
                } catch (_: Exception) { send(null) }
            }
        }

        /** اتصال يدوي بأي شبكة (مثلاً هوتسبوت آخر). */
        @JavascriptInterface fun join(ssid: String, pass: String): Boolean = doJoin(ssid, pass, 60_000)

        @JavascriptInterface fun joinState(): String = joinState
        @JavascriptInterface fun leaveNetwork() = this@MainActivity.leaveNetwork()
    }
}
